"undefined" != typeof postboxes && postboxes.add_postbox_toggles(pagenow);
//# sourceMappingURL=admin-footer.js.map