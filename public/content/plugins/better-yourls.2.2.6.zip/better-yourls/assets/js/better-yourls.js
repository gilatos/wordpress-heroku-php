jQuery(document).ready(function() {
    jQuery("#wp-admin-bar-better_yourls-link").click(function() {
        alert(better_yourls.text + "\n\n" + better_yourls.yourls_url);
    });
});
//# sourceMappingURL=better-yourls.js.map